1.1 "Help Spread DuckDuckGo" message was at the bottom of the page rather than at the upper right.
2. I put the dictionary in the js file, so that I don't have to reference it since we could only submit the html and js file.
3. Similar to 2nd activity, I put the dictionary in the js file.