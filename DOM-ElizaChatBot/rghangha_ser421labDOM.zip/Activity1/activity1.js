//Part1
document.getElementsByClassName("footer__card__title tx-clr--slate")[1].innerHTML="Help Spread Love!";

//Part2
document.getElementsByTagName("li").length;

//Part3
document.getElementById("search_form_input").value;

//Part4
document.querySelector('.header__logo-wrap.js-header-logo').remove();