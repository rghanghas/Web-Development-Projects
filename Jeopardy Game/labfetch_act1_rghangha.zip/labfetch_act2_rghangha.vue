<!-- https://play.vuejs.org/#eNrNWety28YVfpU1RpHAhgJJaZy2NKnEVdOOMlM7bdL2h6iJlsCShA0CMLCQyDJ89357xQIgZcnT6eSHRns95zv3s+DOe5vnwUPFvLE3KcMizvnVLGWbPCs4idiCVgknu1lKSEQ59XtqTEjBeFWkZkZISDlbZkXMyjG5veub5U8VK3mcpVjd7e1qWBUFS/nf9eaYpFWStHevFcXtmMy8mXds9yYak2F78180qdiB9R8TumXFmIzsRi5XBOZhH+fJsIa+ZmVJlyDTYB9l1TxhP7Asp0UEbAualMzuPuIC6NeMFf3rrEr5mFzUeDR6vWHw7N+I/0JP4n+YrfOKMwiotbymm38LBlK82hTWGH+jfBXgkM9XcRlo0W7lpKEAck5Gd33ibkiSPcleAXBgFAxoo5qfvLdgPFxpI8Dovrpr7qwZX2WRMLq6Uq6qxSJhPi0Kuu0Cl8tBCZfzwWZ6pSQpaBplayyck2Hw2gWnRnH554YxDEJXG5bGBDRGwzdkMCCj4VckXNE0ZLO0piYFMh7pGwPdRH0SpxHbOKBDuDNiI14s4hDRsSVTpRLr67f17btbeVtqPKivQBZDTfL171ec5+V4MMhyWCOaBzD+gOZxkK/yb+lauMl0dGroTk92NYv9aU0XG/Vkf8q3OZvOsyxhNL3vGY6EBHzFUr9gZQ60TCjcjIMPJaTvdc6K4BfnrBKsI7RiGcoQZwMQBIbydnin7da9YkLY6K9OIcECWhM2ECzxL4gjMp1ObdjcRL0gpWv2WdI3uPclxOPoKGkZKaCq7Po7eNPQsab0ywVREdh1UMeLNNVmPhFoi8qVyxL7TDiTKyOoG9BNe2mWMkmBEziW7Cblfl4g03D/XqElFow66Fc54Rk52T0Hxr43vu+ZUHVliMt39J2SRJLtkV9/deFcqcnnpGxeQlB3ROyI2dHKGyKywD/h+HBtUxrIg7QroMYpsi6SCwZYi6Mm+X093ROG3P+kiru8nes6nzkr3RwXrlj48W1aPrLC7/h2n1C508lNShbNvuVh37oIx08gFFZTBmuFOHIT5iH/RXGXwTPzfobfzjxyempBwVYvuP8XUUgVgVeaQjdadE2GaDPvWlF5NfMcpT7Lib5+2jCtZH44r9zdNmRTWUHUFnikTPZaSGW7dlx3Xacj3k2qKXyBgOfPELB5rXlBL35FLsnXZFSjNoP/jYaUlZlM0a5yhA+jZAVJtlQULKc6sRwpPaKPbJ7p5FfZsDXPmGgViVwtuzHwfv4BVghkTJVtQAF7YMXWrSZq4ZOYfrIi9g74Mkujv6KG6c7JzQg2+u2RdoCjyfsJ7iE8xTZ9QYBSXTuHIasuPMZpWptZHwlkDXu/8A25nmPulkPea5842SlSe7KiJXmE1kUSXQIlePAVOTnZGWr7V/eyMip5LJpFXKxlG+uKZcucTuwaaKPjFamhUTGayf855n5W3Mmsr4ufar3cEOwYKU5jHuPKf5hSEXrhmoGrbpB/Kxpdt57LB0APLUmS+MNu+u902W1HYJswqSIW1WEn2NyO8JQZXfbJxQh/3+Dv9/j7Y59cYv3yom7JVPM58450n7+Ynki0oTPPdoXP7x+Pdo+tpsx4pnkoyB6SF/FDTA0InHLbUqiMi6Jom8gr8uqANuDjcq20J9HcNfrbMolD5kMxLiT1MnMbmUWGVihh3PaJJFu0pWg1I0deBQBwJ4zU7Bt2zotCvDkZLbd4d+pqKl6B6qkJwzuFRa/qJ9v/i9qaRXG1/u3SWyH4X0DNJeY+V+xG3ZjJRy5SGuaTgf1cgglna0Q0Z5gRMoniBzlQQxImtCynM09mv2VVUOkQM0+fwamEzlly9a5az5F04Fj2u0SNZqIaU/mmm3mpPIp+6eF8nUUswZKTUbC+jlOsXYgR3WD0DUbfSRKYdHIWNgc1moGCcxSd+7HnBQAbsWUhjlxgrYT3BKzJQCn5gJqVIs5LUYQaWs4BBnGMI77ctG/7ODUaB8fxR7bFkTNN5gxF0VevPVTHnkOPEF0Udzv9HMQBst+PUSV3RHLArIaft6DLMacoWDVE5EsaORwmvHBm8oAVwmYiwK9NUkvgJBygBiS7IB7PgDYZ8JXLa+AwE3sulAmfZ9G2icwiUdIDxuuGesSh6EvgQpGSZIsa6M0rztF0jKO4FIqLcO9whnU/vJg8gC95rbfi2PjMjpyZU2fj+rPlUZKNTNInZygzagW3/ecjks+dF3LrIQN1BPkuRBn7CEGeQc1lfvizF26Y2OiYAOnWuLv8+uG4uPEcZaSmIwx4w61brub4FmZOSMjAfjiPF8JBmv1+I7Kle7e+K+33smqLYGw8QoTjm1hs3bVvVKPF9mHtf1bdTz/QxbtGaFA8jjtqeSEtVa0ENflUbpFr5BSR56TGdGOrot90ua5EXSU3O2hHxwe/DtX5/7PZX54X0a7qUaO1n3lOmu+oxXkzAM+1mh6V34zgR3VNxrTkW+lVuvPW5aFPEFxuVVYt3CIT3+XfFiiSKPVwcMWsDh15ak7Dj8sC1Sw6D7MkgzaWBWNp44ZNDMeugJp7oeZ/XqI+j0lCi6V6wXTvzs3DXs+3LEmyR7kiKTyyeLmCIH+QHynBQ4YWuiekZQUnKyJhxYt8Q/DoRuadJ+Ci2Mk9wSqheQkkZiR3cxpFcbrEjxev843lWOvspTIIcKvfGiir2MdVzDVK9H3ak7y+x+FFwnvkuwc/oUn8wmXXeZyw4n2uOz37S8jMo8JEP8g1kR50K6uj/8D6hxJlUHS1P8JdWfGAYLF7XIiAVkpsf//TO7bB2G4i8KoEp5/Y/AeDfiuVTMWxP0EFgO2ck2hv1uLnQCj25/L7DWdpaYQSQM3vPuI0fke8fkL0Gu5lcGlaaW//X+UBPg0= -->
<script>
export default {
  data() {
    return {
      categories: [],
      questions: {},
      currentQuestion: null,
      currentCategory: "",
      currentCategoryId: 0,
      currentValue: 0,
      currentPlayer: 1,
      players: [0, 0, 0],
      message: "",
      doubleJeopardy: false,
      wager: 0,
      playerCount: 2,
      categoryCount: 1,
    };
  },

  computed: {
    maxWagerValue() {
      return Math.max(this.players[this.currentPlayer - 1], this.currentValue);
    },
  },

  created() {
    this.fetchCategories();
  },

  methods: {
    shuffle(array) {
      return array.sort(() => Math.random() - 0.5);
    },

    isDoubleJeopardy() {
  return Math.random() < 0.10; // 10% chance
},

    fetchQuestion(categoryId, index) {
      const difficulty = this.questions[categoryId][index - 1].difficulty;

      fetch(`https://opentdb.com/api.php?amount=1&category=${categoryId}&difficulty=${difficulty}&type=boolean`)
        .then(response => response.json())
        .then(data => {
          this.currentQuestion = data.results[0];
          this.currentCategory = this.categories.find(cat => cat.id === categoryId).name;
          this.currentCategoryId = this.categories.find(cat => cat.id === categoryId).id;
          this.currentValue = index * 100;

          if (this.isDoubleJeopardy()) {
        this.doubleJeopardy = true;
        if (this.players[this.currentPlayer - 1] >= this.currentValue) {
            this.wager = parseInt(prompt(`Double Jeopardy wager (up to ${this.players[this.currentPlayer - 1]}):`));
            if (isNaN(this.wager) || this.wager > this.players[this.currentPlayer - 1] || this.wager < 0) {
                this.wager = this.currentValue;  // Use the current value if input is invalid
            }
        } else {
            this.wager = this.currentValue;
        }
    }
        });
    },

    checkAnswer(currentCategoryId, answer) {
      const value = this.doubleJeopardy ? this.wager : this.currentValue;
      if ((this.currentQuestion.correct_answer === "True" && answer) || (this.currentQuestion.correct_answer === "False" && !answer)) {
        this.message = "Correct!";
        this.players[this.currentPlayer - 1] += this.currentValue;
        this.questions[this.currentCategoryId][(this.currentValue / 100) - 1].correctAnswer = true;
      } else {
        this.message = "Incorrect!";
        this.players[this.currentPlayer - 1] -= this.currentValue;
        this.currentPlayer = this.currentPlayer % 3 + 1;
      }
      this.questions[this.currentCategoryId][(this.currentValue / 100) - 1].answered = true;
      console.log(this.questions);
      this.currentQuestion = null;
      this.doubleJeopardy = false;
      this.wager = 0;
      
      if (Object.values(this.questions).every(cat => cat.every(q => q.answered))) {
        this.endGame();
      }
    },

    endGame() {
      const maxScore = Math.max(...this.players);
    const winner = this.players.indexOf(maxScore) + 1;
    this.message = `Player ${winner} has won the game with $${maxScore}!`;

},


    confirmWager() {
      if (this.wager <= this.maxWagerValue && this.wager > 0) {
        this.doubleJeopardy = false;
      } else {
        this.message = "Invalid wager amount!";
      }
    },

    initializePlayers() {
      this.players = Array(this.playerCount).fill(0);
    },

    fetchCategories() {
      const excludedCategoryIds = [10, 13, 21, 26, 27, 29, 30, 32];
      fetch("https://opentdb.com/api_category.php")
      .then(response => response.json())
      .then(data => {
        this.categories = this.shuffle(data.trivia_categories)
        .filter(category => !excludedCategoryIds.includes(category.id))
        .slice(0, this.categoryCount);
        for (let category of this.categories) {
          this.questions[category.id] = [
            { difficulty: "easy", answered: false, correctAnswer: false },
            { difficulty: "easy", answered: false, correctAnswer: false },
            { difficulty: "medium", answered: false, correctAnswer: false },
            { difficulty: "medium", answered: false, correctAnswer: false },
            { difficulty: "hard", answered: false, correctAnswer: false }
          ];
        }
      });
    }
  }
};
</script>

<template>
  <div>
    <div class="configurations">
      <label>Number of players: 
        <input type="number" v-model="playerCount" min="2" max="6" @input="initializePlayers" />
      </label>
      <label>Number of categories: 
        <input type="number" v-model="categoryCount" min="1" @input="fetchCategories" />
      </label>
    </div>

    <div class="player-scores">
      <p v-for="(score, index) in players" :key="'player-' + (index + 1)">
        Player {{ index + 1 }}: ${{ score }}
      </p>
    </div>
    <table>
      <thead>
        <tr>
          <th v-for="category in categories" :key="category.id">{{ category.name }}</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="index in 5">
          <td v-for="category in categories" :key="category.id + index">
            <button :disabled="questions[category.id][index - 1].answered"
              :class="{ 'answered': questions[category.id][index - 1].correctAnswer, 'incorrect': (questions[category.id][index - 1].answered && !questions[category.id][index - 1].correctAnswer) }"
              @click="!questions[category.id][index - 1].answered && fetchQuestion(category.id, index)">
              {{ index * 100 }}
            </button>
          </td>
        </tr>
      </tbody>
    </table>
    <div v-if="currentQuestion">
      <p>{{ currentCategory }} for ${{ currentValue }}</p>
      <p>{{ currentQuestion.question }}</p>
      <button @click="checkAnswer(currentCategoryId,true)">True</button>
      <button @click="checkAnswer(currentCategoryId, false)">False</button>
    </div>
    <p v-if="message">{{ message }}</p>
    
    <div v-if="doubleJeopardy">
      Double Jeopardy wager: 
      <input type="number" v-model="wager" :max="maxWagerValue"/>
      <button @click="confirmWager">Confirm</button>
    </div>
  </div>
</template>

<style>
.player-scores, .configurations {
  font: Arial;
}
button.answered {
  background-color: green;
}
button.incorrect {
  background-color: red;
}
button {
  font-size: large;
  background-color: blue;
  color: yellow;
  font-weight: 800;
}
table,
td {
  border: 2px solid black;
  border-collapse: collapse;
  padding: 15px;
  font: Arial;
  font-size: large;
  background-color: blue;
}
th {
  border: 2px solid black;
  border-collapse: collapse;
  padding: 15px;
  font: Arial;
  font-size: large;
  background-color: blue;
  color: white;
}
</style>
